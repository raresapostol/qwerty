clc 
clear

filenames = ["Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility1-Transmitter-Transmitter2_Doppler_Input_noxyz.csv";   
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility10-Transmitter-Transmitter10_Doppler_Input_noxyz.csv";  
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility2-Transmitter-Transmitter1_Doppler_Input_noxyz.csv";    
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility3-Transmitter-Transmitter3_Doppler_Input_noxyz.csv";    
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility4-Transmitter-Transmitter4_Doppler_Input_noxyz.csv"; 
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility5-Transmitter-Transmitter5_Doppler_Input_noxyz.csv";    
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility6-Transmitter-Transmitter6_Doppler_Input_noxyz.csv";   
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility7-Transmitter-Transmitter7_Doppler_Input_noxyz.csv";    
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility8-Transmitter-Transmitter8_Doppler_Input_noxyz.csv";    
"Satellite-Satellite1-Receiver-Receiver1-To-Facility-Facility9-Transmitter-Transmitter9_Doppler_Input_noxyz.csv"];

x = {};

for i = 1:length(filenames)
    file = read_stk_file(filenames(i));
    doppler_rate = generate_doppler_rate(file);
    file = addvars(file,doppler_rate);
    x{end + 1} = file;
end

figure
for i = 1:length(filenames)
    plot(x{1,i}.Time,x{1,i}.Rcvd_Frequency_MHz_)
    title("Rcvd_Frequency")
    xlabel("Time")
    ylabel("GHz")
    hold on
end

figure
for i = 1:length(filenames)
    plot(x{1,i}.Time,x{1,i}.doppler_rate)
    title("Doppler_rate")
    xlabel("Time")
    ylabel("GHz/s")
    hold on
end

figure
for i = 1:length(filenames)
    plot(x{1,i}.Time,x{1,i}.Elevation_deg_)
    title("Elevation")
    xlabel("Time")
    ylabel("Deg")
    hold on
end

find_closest_approach(x{1,1}.Time,x{1,1}.doppler_rate)

figure
sens_doppler = x{1,3}.doppler_rate + 0.5e-6 * rand(1,1);
hold on
plot(sens_doppler)
plot(x{1,3}.doppler_rate)


function file = read_stk_file(filename)
    %function reads stk file and generates a timetable
    %function generates doppler rate
    %replace "Time (yy:mm:dd)" with Time in files imported from STL
    file = readtable(filename,'Delimiter',',');
    file.Time = datetime(file.Time,'InputFormat','yyyy:MM:dd:HH:mm:ss.SSS');
    file = table2timetable(file);
end

function doppler_rate = generate_doppler_rate(file)
    %generate doppler rate from given file
    format long
    doppler_rate = [diff(file.Rcvd_Frequency_MHz_)./seconds(diff(file.Time)) ; 0];
end

function [time_closest_approach, index_closest_approach] = find_closest_approach(time_vector,doppler_rate)
    [Value,index_closest_approach] = min(doppler_rate);
    time_closest_approach = time_vector(index_closest_approach);
end
